# backend

conda create -n fastapi_tf python==3.10 numpy==1.23.1

pip install fastapi uvicorn python-multipart opencv-python tensorflow==2.8.0 keras numpy==1.23.1 protobuf==3.20

# frontend

npx create-react-app frontend
cd frontend
npm start

## frontend 공유 받았을 때 실행하는 방법

frontend 있는 곳으로 이동 한 후
npm install
npm run start
